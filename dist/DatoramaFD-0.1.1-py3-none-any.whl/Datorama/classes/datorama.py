import requests,time,os,pickle,inspect
import numpy as np
import pandas as pd
from math import ceil
from time import sleep
from pathlib import Path
from random import random
from datetime import datetime as dt

from Datorama import Connect,Workspace,Bad_HTTP_Response,Unequal_Input_Error


class datorama():
    '''
    Main class representing the parent Datorama object.
        Inputs:
            api_token (str)
                The api token provided by Datorama.
            verbose (boolean)
                Determines the amount of feedback to be returned to the user. Useful for debugging.
            pause (int,float)
                The length of time to sleep between standard iterated requests.
                The Datorama platform api has a limit of 60 requests per minute so the default pause is 1 second.
    '''


    def __init__(self,api_token,verbose=False,pause=1.5,platform_rate_limit=59,platform_rate_pause=30,debug=False):
        self.restore_path = Path(os.path.dirname(inspect.getsourcefile(datorama) ) ) / 'restore.data'
        self.logs = {'job_log':{},'update_log':[],'error_log':{} }
        self.connection = Connect(
            datorama=self,api_token=api_token,verbose=verbose,pause=pause,
            platform_rate_limit=platform_rate_limit,platform_rate_pause=platform_rate_pause,
            debug=debug
            )
        self.jobs = {}
        self.streams = {}
        self.get_workspaces()


    def restore_state(self):
        ''''''

        retries = 0
        while retries < 10:
            try:
                with open(self.restore_path,'rb') as f:
                    restored = pickle.load(f)
                age = restored.get('saved')
                if age.date() == dt.now().date():
                    self.workspaces = restored.get('spaces')
                    self.streams = restored.get('streams')
            
            except:
                retries += 1
                sleep(random() )
        
        if not self.workspaces: self.get_workspaces()
        if not self.streams: self.get_all_streams()


    def save_state(self):
        ''''''

        save = {'spaces':self.workspaces,'streams':self.streams,'saved':dt.now()}
        with open(self.restore_path,'wb') as f:
            pickle.dump(save,f)


    def log_error(self,source_module,function_triggered,error_raised,detail):
        '''Adds record to the error log.'''

        self.logs['error_log'].update(
                { (len(self.logs['error_log'])+1):{'module':source_module,'function':function_triggered,'timestamp':str(dt.now() ),'error_raised':error_raised,'detail':str(detail) } }
            )


    def log_job(self,workspace,stream,job,job_type,start,end,isError=False):
        '''Add a record to the job log.'''

        status = 'queued'
        if isError:
            status = 'error'
            
        if workspace not in self.logs['job_log']: self.logs['job_log'][workspace] = {}
        if stream not in self.logs['job_log'][workspace]: self.logs['job_log'][workspace][stream] = {}

        self.logs['job_log'][workspace][stream].update(
            {job:{
                'workspace':workspace,'stream':stream,'job':job,
                'job_type':job_type,'start':start,'end':end,'status':status,
                'exec_start':dt.now(),'exec_end':'nat'
                }
            }
        )


    def get_workspaces(self):
        '''Get request to pull the metadata for all workspaces from the api.'''
        
        try:
            if self.connection.verbose:
                print('getting workspaces')

            self.get_workspaces_response = self.connection.call(method='GET',endpoint='/v1/workspaces')
            self.ws_content = self.get_workspaces_response.json()
            self.workspaces = {ws.get('id'):Workspace(self,attributes=ws) for ws in self.ws_content}
            self.save_state()

        except Exception as X:
            self.log_error(source_module='datorama',function_triggered='get_workspace',error_raised=str(X),detail='No valid response')


    def _feedback(self,timeseries,length,index,split=4):
        '''
        Returns feedback to the user about the iteration progress.
            Inputs:
                timeseries (pandas.series)
                    A pandas series containing the execution time of each iteration.
                length (int)
                    The total length of the iteration.
                index (int)
                    The current iteration index.
                split (int)
                    The number of slices to split the dataset into; Used to determine when to provide feedback.
        '''

        if index in [ ( (length//split) * i) for i in range(1,split) ] and length > 2:
                print(f'\tprogress: { round( (index/length*100), 2) }%')
                print(f'\test compl: { timeseries.mean() * (length - index + 1) }')


    def get_all_dimensions(self):
        '''Loop through all workspaces and retrieve the dimensions.'''

        print('- getting dimensions for all workspaces -')
        
        print('\tmaking calls to api')
        self.dimensions = {}
        cnt = len(self.workspaces)
        ts = pd.Series()
        for idx,space in enumerate(self.workspaces):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            self.workspaces.get(space).get_dimensions()
            self.dimensions.update( {space:self.workspaces.get(space).dimensions} )

            ts = ts.append(pd.Series(dt.now()-st) )        
        print('\tdone')


    def create_stream_df(self,export=False,export_name='Datorama Stream Meta Data.csv',fields=None):
        '''
        Creates a pandas data frame from the stream data.
            Inputs:
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
                export_name (str)
                    The output filename with extension. Must be a csv file.
        '''

        if not self.streams:
            self.get_all_streams(create_df=False)

        if not fields:
            fields = [
                    'id','name','dataSourceId','sourceDisplayName','workspaceId',
                    'enabled','hasData','dataSourceAuthenticationId','createTime',
                    'lastUpdate','lastRunStatus','lastRowsRetrieved','processedRows',
                    'lastDataDate'
                ]
        
        print('- creating stream data frame -')
        cnt = len(self.streams)
        ts = pd.Series()
        self.stream_meta = []
        for idx,stream in enumerate(self.streams.values() ):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            self.stream_meta.append( {x:stream.__dict__.get(x) for x in stream.__dict__ if x in fields} )
            ts = ts.append(pd.Series(dt.now()-st) )

        self.stream_df = pd.DataFrame(self.stream_meta).reset_index()
        self.stream_df['createTime'] = pd.to_datetime(self.stream_df['createTime'],unit='ms')
        self.stream_df['lastUpdate'] = pd.to_datetime(self.stream_df['lastUpdate'],unit='ms')

        if export:
            self.stream_df.to_csv(export_name,index=False)
        print('- done -')


    def get_all_streams(self,create_df=True,workspaces=None):
        '''Loops through all workspace objects and triggers each ones 'get_streams' function.'''

        print('- getting metadata for all streams -')        
        if not workspaces:
            workspaces = self.workspaces
        else:
            workspaces = {k:v for k,v in self.workspaces.items() if v.id in workspaces}
        
        print('\tmaking calls to api')
        cnt = len(workspaces)
        ts = pd.Series()
        for idx,space in enumerate(workspaces):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            self.workspaces.get(space).get_streams()

            ts = ts.append(pd.Series(dt.now()-st) )
        
        self.save_state()
        if create_df: self.create_stream_df()
        print('- done -')


    def create_jobs_df(self,export=False,export_name='Datorama Job Run Data.csv'):
        '''
        Creates a pandas data frame from the jobs data.
            Inputs:
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
                export_name (str)
                    The output filename with extension. Must be a csv file.
        '''

        if not self.jobs:
            self.get_all_jobs(create_df=False)

        print('- creating job data frame -')

        exclusions = ['connection','logs']

        cnt = len(self.streams)
        ts = pd.Series()
        job_meta = []
        for idx,job in enumerate(self.jobs.values() ):
            st = dt.now()
            self._feedback(ts,cnt,idx,split=8)
            job_meta.append( {x:job.__dict__.get(x) for x in job.__dict__ if x not in exclusions} )
            ts = ts.append(pd.Series(dt.now()-st) )

        self.jobs_df = pd.DataFrame(job_meta).reset_index()
        self.jobs_df['startExecutionTime'] = pd.to_datetime(self.jobs_df['startExecutionTime'],unit='ms')
        self.jobs_df['endExecutionTime'] = pd.to_datetime(self.jobs_df['endExecutionTime'],unit='ms')

        if export:
            self.jobs_df.drop('processLog',axis=1).to_csv(export_name,index=False)
        print('- done -')


    def get_all_jobs(self,create_df=True):
        '''Loops through all data stream objects and triggers each ones 'get_stream_runs' function.'''

        print('- getting metadata for all stream runs -')
        if not self.streams:
            self.get_all_streams()

        print('\tmaking calls to api')
        cnt = len(self.streams)
        ts = pd.Series()
        for idx,stream in enumerate(self.streams):
            st = dt.now()
            self._feedback(ts,cnt,idx,split=16)
            self.streams.get(stream).get_stream_runs()
            ts = ts.append(pd.Series(dt.now()-st) )

        if create_df:
            self.create_jobs_df()
        print('- done -')

    def create_job_log_df(self,log_file='job_log.csv',export=False):
        '''
                log_file (str)
                    The output filename with extension for the process log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                error_file (str)
                    The output filename with extension for the error log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        jobs = self.logs['job_log']
        job_log = pd.DataFrame( [job for space in jobs.values() for stream in space.values() for job in stream.values()] )
        if export:
            if log_file and os.path.exists(log_file):
                old_log = pd.read_csv(log_file)
                job_log = job_log.append(old_log)
            job_log = job_log.drop_duplicates()
            job_log.to_csv(log_file,index=False)
        self.jldf = job_log


    def create_error_log_df(self,error_file='error_log.csv',export=False):
        ''' '''

        errors = self.logs['error_log']
        error_log = pd.DataFrame( [x for x in errors.values()] )
        if export:
            error_log.to_csv(error_file,index=False)
        self.eldf = error_log


    def bulk_process_streams(self,streams,starts,ends,d_range=10,create_df=True,export=False,process_file='process_log.csv'):
        '''
        Process an iterable of stream ids using the process_stream() function. Streams, starts, and ends must be the same length.
            Inputs:
                streams (iterable)
                    The list, array, or series representing the list of stream ids to process.
                starts (iterable)
                    The list, array, or series representing the list of start dates to process.
                ends (iterable)
                    The list, array, or series representing the list of end dates to process.
                d_range (integer)
                    Days to partition the day range by.

        '''

        print(f'- processing {len(streams)} streams -')
        if not self.streams:
            self.get_all_streams()

        if not ( len(streams) == len(starts) == len(ends) ):
            raise Unequal_Input_Error()

        jobs = []
        for (s,st,en) in zip(streams,starts,ends):
            for stream,start,end in self.date_partition_check(s,st,en,d_range):
                jobs.append( {'stream':stream,'start':start,'end':end,'status':'na'} )

        ts = pd.Series();cnt = len(jobs)
        all_jobs_submitted = lambda: all( [x.get('status') in ['submitted','failure'] for x in jobs] )
        all_jobs_complete = False
        print(f'- processing {cnt} jobs -')
        while not all_jobs_complete:
            for idx,job in enumerate(jobs):
                if job.get('status') in ['submitted','failure']:
                    continue
                else:
                    st = dt.now()
                    job_stream = self.streams.get(job.get('stream') )
                    if not job_stream:
                        self.log_error(source_module='datorama',function_triggered='bulk_rerun_all',error_raised='Suppressed',detail=f'stream {job.get("stream")} not found')
                        job.update( {'status':'failure'} )
                        continue
                    if not job.get('workspace'):
                        job.update({'workspace':job_stream.workspaceId})
                    exec_stat = job_stream.process(job.get('start'),job.get('end'))
                    if not exec_stat:
                        continue
                    if exec_stat == 'failed':
                        job.update( {'status':'failure'} )
                        continue
                    job.update( {'status':'submitted'} )
                    ts = ts.append(pd.Series(dt.now()-st) )
            
            if all_jobs_submitted():
                total = sum( [space.pending for space in self.workspaces.values() if space.ws_state != 'idle'] )
                print(f'total pending: {total}')
                if all( [space.ws_state != 'active' for space in self.workspaces.values()] ):
                    all_jobs_complete = True
            
            for space in self.workspaces.values():
                if space.ws_state == 'active':
                    space.queue_check()

            spaces_with_jobs_left = lambda: set([x.get('workspace') for x in jobs if x.get('status') not in ['submitted','failure'] ])
            all_spaces_busy = lambda: all( [space.ws_state == 'active' for space in self.workspaces.values() if space.id in spaces_with_jobs_left() ] )
            if all_jobs_submitted() or all_spaces_busy():
                bandwidth = any([self.workspaces.get(x).pending < self.workspaces.get(x).queue_max for x in spaces_with_jobs_left() ] )
                if bandwidth:
                    continue
                pending_cnt = [self.workspaces.get(x).pending for x in spaces_with_jobs_left() ]
                stime = min(pending_cnt)//10
                print(pending_cnt)
                print('spaces with jobs remaining',spaces_with_jobs_left() )
                print(f'all active workspaces are busy, pausing for {stime*2} minutes')
                sleep(stime*120)
        
        if create_df: self.create_job_log_df(log_file=process_file,export=export)
        print('- done -')

    
    def date_partition_check(self,stream,start,end,d_range):
        ''''''

        days = pd.DatetimeIndex(start=start, end=end, freq='D').tolist()
        if len(days) > d_range:
            days = np.array_split(days,ceil(len(days)/d_range) )
            st_part = [str(d[0].date() ) for d in days]
            en_part = [str(d[-1].date() ) for d in days]
            return [(stream,st_pt,en_pt) for st_pt,en_pt in zip(st_part,en_part)]
        else:
            return [(stream,start,end)]


    def bulk_rename_streams(self,streams,names,export=True,update_file='update_log.csv'):
        '''
        Packages the name into a dictionary and passes it to the streams' 'update_stream' function.
            Inputs:
                streams (integer, string, or list)
                names (string or list)
                update_file (str)
                    The output filename with extension for the update log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        if not self.streams:
            self.get_all_streams()

        if type(streams) not in (str,int) and type(names) not in (str,int):    
            if not (len(streams) == len(names) ):
                raise Unequal_Input_Error()
        else:
            streams,names = [streams],[names]
        
        ts = pd.Series()
        cnt = len(streams)
        print(f'- updating {cnt} streams -')
        for idx,(stream,name) in enumerate( zip(streams,names) ):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            self.streams.get(stream).update_stream( {'name':name} )

            ts = ts.append(pd.Series(dt.now()-st) )

        if export:
            update_log = pd.DataFrame(self.logs['update_log'])
            if update_file and os.path.exists(update_file):
                old_update_log = pd.read_csv(update_file)
                update_log = update_log.append(old_update_log)
            update_log.to_csv(update_file,index=False)
        print('- done -')


    def rerun_all(self,streams,create_df=True,export=False,file_name='job_log'):
        ''''''
        
        jobs = [ {'stream':stream,'status':'na'} for stream in streams]
        self.execute_job(
            job_dict=jobs,job_type='rerun_all',
            create_df=create_df,export=export,file_name=file_name
        )



    def execute_job(self,job_dict,job_type,create_df=True,export=False,file_name='job_log'):
        ''''''

        job_funct = lambda x: {'rerun_batch':x.rerun_job_batch,'rerun_all':x.rerun_all_jobs,'process':x.process}[job_type]
        all_jobs_submitted = lambda: all( [x.get('status') in ['submitted','failure'] for x in job_dict] )
        submitted_count = lambda: len( [1 for x in job_dict if x.get('status') in ['submitted','failure'] ] )
        spaces_with_jobs_left = lambda: set([x.get('workspace') for x in job_dict if x.get('status') not in ['submitted','failure'] ])
        bandwidth = lambda: any( [space.pending < space.queue_max for space in self.workspaces.values() if space.id in spaces_with_jobs_left() ] )

        if not self.streams:
            self.get_all_streams()

        ts = pd.Series();cnt = len(job_dict)
        all_jobs_complete = False
        print(f'- executing {cnt} jobs -')
        while not all_jobs_complete:
            for job in job_dict:
                if job.get('status') in ['submitted','failure']:
                    continue
                else:
                    st = dt.now()
                    job_stream = self.streams.get(job.get('stream') )
                    if not job_stream:
                        self.log_error(source_module='datorama',function_triggered='bulk_rerun_all',error_raised='Suppressed',detail=f'stream {job.get("stream")} not found')
                        continue
                    exec_stat = job_funct(job_stream)()
                    if not exec_stat:
                        continue
                    if exec_stat == 'failed':
                        job.update( {'status':'failure'} )
                        continue
                    job.update( {'status':'submitted'} )
                    self._feedback(ts,cnt,submitted_count(),split=16)
                    ts = ts.append(pd.Series(dt.now()-st) )
            
            total = sum( [space.pending for space in self.workspaces.values() ] )
            print(f'total pending: {total}')
            
            if all_jobs_submitted():
                if all( [space.ws_state != 'active' for space in self.workspaces.values()] ):
                    all_jobs_complete = True
            
            for space in self.workspaces.values():
                if space.ws_state == 'active':
                    space.queue_check()

            if all_jobs_submitted() or not bandwidth():
                print('no bandwidth for additional jobs, pausing for five minutes')
                sleep(300)
        
        if create_df:
            self.create_job_log_df(log_file=f"{file_name} {job_type} {dt.now().strftime('%Y-%m-%d %H_%M_%S')}.csv",export=export)
        print('- done -')


    def bulk_rerun_all(self,streams,create_df=True,export=False,rerun_file='rerun_log.csv'):
        ''''''
        
        jobs = [ {'stream':stream,'status':'na'} for stream in streams]
        
        if not self.streams:
            self.get_all_streams()

        ts = pd.Series();cnt = len(jobs)
        all_jobs_submitted = lambda: all( [x.get('status') in ['submitted','failure'] for x in jobs] )
        all_jobs_complete = False
        print(f'- rerunning {cnt} streams -')
        while not all_jobs_complete:
            for idx,job in enumerate(jobs):
                if job.get('status') in ['submitted','failure']:
                    continue
                else:
                    st = dt.now()
                    job_stream = self.streams.get(job.get('stream') )
                    if not job_stream:
                        self.log_error(source_module='datorama',function_triggered='bulk_rerun_all',error_raised='Suppressed',detail=f'stream {job.get("stream")} not found')
                        job.update( {'status':'failure'} )
                        continue
                    if not job.get('workspace'):
                        job.update({'workspace':job_stream.workspaceId})
                    exec_stat = job_stream.rerun_all_jobs()
                    if not exec_stat:
                        continue
                    if exec_stat == 'failed':
                        job.update( {'status':'failure'} )
                        continue
                    job.update( {'status':'submitted'} )
                    ts = ts.append(pd.Series(dt.now()-st) )
            
            if all_jobs_submitted():
                total = sum( [space.pending for space in self.workspaces.values() if space.ws_state != 'idle'] )
                print(f'total pending: {total}')
                if all( [space.ws_state != 'active' for space in self.workspaces.values()] ):
                    all_jobs_complete = True
            
            for space in self.workspaces.values():
                if space.ws_state == 'active':
                    space.queue_check()

            spaces_with_jobs_left = lambda: set([x.get('workspace') for x in jobs if x.get('status') not in ['submitted','failure'] ])
            all_spaces_busy = lambda: all( [space.ws_state == 'active' for space in self.workspaces.values() if space.id in spaces_with_jobs_left() ] )
            if all_jobs_submitted() or all_spaces_busy():
                pending_cnt = [self.workspaces.get(x).pending for x in spaces_with_jobs_left() ]
                if not pending_cnt:
                    print(f'all active workspaces are busy, pausing for 2 minutes')
                    sleep(120)
                stime = min(pending_cnt)//10
                print('spaces with jobs remaining',spaces_with_jobs_left() )
                print('status',[space.ws_state == 'active' for space in self.workspaces.values() if space.id in spaces_with_jobs_left() ])
                print(f'all active workspaces are busy, pausing for {stime*2} minutes')
                sleep(120)
        
        if create_df: self.create_job_log_df(log_file=rerun_file,export=export)
        print('- done -')



    def bulk_rerun_jobs(self,streams,jobs,create_df=True,export=False,rerun_file='rerun_log.csv'):
        '''
        Groups the jobs by their stream and passes the list of jobs to the streams' 'rerun_job_batch' function.
            Inputs:
                streams (list)
                    List representing the stream that each job belongs to.
                jobs (list)
                    List representing the job ids to rerun.
                log_file (str)
                    The output filename with extension. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                error_file (str)
                    The output filename with extension. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        if not self.streams:
            self.get_all_streams()
        
        rerun_df = pd.DataFrame( {'stream':streams,'job':jobs} )
        jobs = [ {'stream':stream,'status':'na'} for stream in rerun_df.stream.unique() ]
        for x in jobs:
            batch = rerun_df[rerun_df['stream'] == x.get('stream')]['job'].to_list()
            x.update( {'jobs':batch} )

        ts = pd.Series();cnt = len(jobs)
        all_jobs_submitted = lambda: all( [x.get('status') in ['submitted','failure'] for x in jobs] )
        all_jobs_complete = False
        print(f'- rerunning {cnt} streams -')
        while not all_jobs_complete:
            for idx,job in enumerate(jobs):
                if job.get('status') in ['submitted','failure']:
                    continue
                else:
                    st = dt.now()
                    self._feedback(ts,cnt,idx,split=32)
                    exec_stat = self.streams.get(job.get('stream') ).rerun_job_batch(job.get('jobs') )
                    if not exec_stat:
                        continue
                    if exec_stat == 'failed':
                        job.update( {'status':'failure'} )
                        continue
                    job.update( {'status':'submitted'} )
                    ts = ts.append(pd.Series(dt.now()-st) )
            
            if all_jobs_submitted():
                total = sum( [space.pending for space in self.workspaces.values() if space.ws_state != 'idle'] )
                print(f'total pending: {total}')
                if all( [space.ws_state != 'active' for space in self.workspaces.values()] ):
                    all_jobs_complete = True

            for space in self.workspaces.values():
                if space.ws_state == 'active':
                    space.queue_check()

            all_spaces_busy = lambda: all( [space.ws_state in ['active','idle'] for space in self.workspaces.values()] )
            
            if all_jobs_submitted() or all_spaces_busy():
                print('all active workspaces are busy, pausing for five minutes')
                sleep(300)

        if create_df: self.create_job_log_df(log_file=rerun_file,export=export)
        print('- done -')