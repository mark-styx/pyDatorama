import requests,json,pickle,os,inspect
from time import sleep
from pathlib import Path
from random import random
from datetime import datetime as dt

from Datorama import Bad_HTTP_Response

class Connect():
    ''' Connection class that retains the connection parameters. '''

    def __init__(self,datorama,api_token,verbose,pause,platform_rate_limit=59,platform_rate_pause=10,debug=False):
        self.conn_path = Path(os.path.dirname(inspect.getsourcefile(Connect) ) ) / 'connection.data'
        self.verbose,self.pause = verbose,pause
        self.api_url = 'https://api-us2.datorama.com'
        self.platform_rate_limit,self.platform_rate_pause = platform_rate_limit,platform_rate_pause
        self.standard_header = {'Authorization':api_token,'Accept':'application/json','Content-Type':'application/json'}
        self.active_platform_calls,self.total_calls,self.daily_calls = 0,0,0
        self.logs,self.log_error = datorama.logs,datorama.log_error
        self.active_platform_log,self.daily_log,self.call_history = [],[],{}
        if debug: self.dr_state = datorama
        self.debug = debug


    def load_connection(self):
        ''''''

        retries = 0
        loaded = False
        while not loaded:
            if retries >= 15:
                print('Failed to load connection data and retries exceeded limit, overwriting file.')
            try:
                if not os.path.exists(self.conn_path):
                    loaded = True
                else:
                    with open(self.conn_path,'rb') as f:
                        data = pickle.load(f)
                    self.active_platform_log = data.get('active_calls')
                    self.daily_log = data.get('daily_calls')
                loaded = True

            except:
                sleep( random() )
                retries += 1


    def save_connection(self):
        ''''''
        
        retries = 0
        saved = False
        while not saved:
            if retries >= 5:
                print('Failed to save connection data and retries exceeded limit.')
                raise RuntimeError()
            try:
                data = {
                    'active_calls':self.active_platform_log,
                    'daily_calls':self.daily_log
                }
                with open(self.conn_path,'wb') as f:
                    pickle.dump(data,f)
                saved = True

            except:
                sleep( random() )
                retries += 1



    def call(self,method,endpoint,body=None,call_type='platform'):
        '''Makes the api request; Raises error if response not 200 or 201.'''

        req = 'pre-submission'
        try:

            self.add_call(call_type)
            if body:
                body = json.dumps(body)
            req = requests.request(method=method,url=self.api_url + endpoint,headers=self.standard_header,data=body)
            self.call_history.update( {self.total_calls:{'method':method,'endpoint':endpoint,'status':req.status_code}  } )

            if req.status_code not in [200,201]:
                if self.verbose:
                    print(f'\terror: {req.status_code}')
                raise Bad_HTTP_Response(req.status_code)

            if self.verbose:
                print( f'\tresponse: {req.status_code}' )
                print('- done -')
            
            sleep(self.pause)
            return req

        
        except Exception as X:
            self.log_error(source_module='connection',function_triggered='call',error_raised=str(X),detail=str(req.content) )


    def add_call(self,call_type):
        '''Adds an interval to the api call count, warns every 5000th instance call, and triggers the active call updates.'''

        self.total_calls += 1
        self.load_connection()
        
        if self.debug:
            if self.verbose:
                print('backing up program state')
            self.backup()

        if self.verbose:
            print(f'instance calls: {self.total_calls}')
        if self.total_calls%5000 == 0:
            print(f'warning: instance has made {self.total_calls} calls')

        self.daily_log.append( dt.now() )
        self.update_daily_calls()

        if call_type=='platform':
            self.active_platform_log.append( dt.now() )
            self.update_platform_calls()

        self.save_connection()

    
    def update_daily_calls(self):
        ''''''

        self.daily_log = [x for x in self.daily_log if (dt.now() - x).total_seconds() < 86400]
        self.daily_calls = len(self.daily_log)
        self.check_daily_calls()

    
    def check_daily_calls(self):
        ''''''

        if self.daily_calls > 15000:
            print('- daily rate limit reached -')
            raise RuntimeError()


    def update_platform_calls(self):
        '''Updates the active platform calls.'''

        self.active_platform_log = [x for x in self.active_platform_log if (dt.now() - x).total_seconds() < 61]
        self.active_platform_calls = len(self.active_platform_log)
        self.check_platform_calls()


    def check_platform_calls(self):
        '''Checks the number of active calls and pauses for the set time if the limit is reached.'''

        while self.active_platform_calls > self.platform_rate_limit:
            print('rate limit reached, pausing')
            print(f'oldest active call expires in { 60 - (dt.now() - min(self.active_platform_log) ).total_seconds() } seconds')
            sleep(self.platform_rate_pause)
            self.update_platform_calls()

        if self.verbose:
            print(self.active_platform_calls)

        else:
            pass

    
    def backup(self):
        ''''''

        with open('datorama_state.backup','wb') as f:
            pickle.dump(self.dr_state,f)