import requests
from datetime import datetime as dt

from Datorama import Bad_HTTP_Response,MissingStreamName
from Datorama import Stream


class Workspace():
    ''' Workspace class to represent the Datorama workspace object. '''

    def __init__(self,datorama,attributes=None,workspace_id=None):
        self.pending = 0
        self.logs,self.jobs = datorama.logs,datorama.jobs
        self.streams,self.connection = datorama.streams,datorama.connection
        if workspace_id:
            self.id = workspace_id
            self.get_meta_data()
        if attributes:
            self.__dict__.update(attributes)


    def get_meta_data(self):
        '''Get the metadata for the workspace.'''

        try:
            if self.connection.verbose:
                print('getting workspace metadata')

            self.get_meta_data_response = requests.get(
                self.connection.api_url + f'/v1/workspaces/{self.id}',
                headers = self.connection.standard_header
            )
            self.connection.add_call()
            
            if self.get_meta_data_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_meta_data_response.status_code}')
                raise Bad_HTTP_Response(self.get_meta_data_response.status_code)

            self.__dict__.update(self.get_meta_data_response.json() )

            if self.connection.verbose:
                print( f'\tresponse: {self.get_meta_data_response}' )
                print('- done -')
        
        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'get_meta_data','timestamp':dt.now(),'error_raised':str(X),'api_response':str(self.get_meta_data_response.content) }
            )


    def queue_check(self,job_type):
        '''Checks the jobs that have been submitted to determine how many are still pending.'''
        
        if self.connection.verbose:
            print('- updating job queue -')

        jobs = self.logs[job_type]
        pending = { jobId:job for jobId,job in jobs.items() if job.get('result') not in ['success','failure'] }
        all_streams = [x.get('stream') for x in pending.values() ]

        streams = []
        for stream in all_streams:
            if stream not in streams: streams.append(stream)
        for stream in streams:
            self.streams.get(stream).get_stream_runs()

        for job in pending:
            if self.connection.verbose:
                print(f'\tretrieving status for: {job}')

            meta = self.jobs.get(job)
            if self.connection.verbose:
                print(f'\treceived meta: {meta}')

            jobs[job].update( {'result':meta.status.lower()} )
            if meta.status.lower() in ['success','failure']:
                try:
                    completed = dt.strptime(meta.processLog.split('[')[-1].split(']')[0][:-1],r'%Y-%m-%d %H:%M:%S')
                except:
                    completed = dt.now()
                jobs[job].update( {'completed':completed} )
        self.pending = len( { jobId:job for jobId,job in jobs.items() if job.get('result') not in ['success','failure'] } )


    def get_dimensions(self):
        '''Get the list of dimensions used in the workspace.'''

        try:
            if self.connection.verbose:
                print(f'- getting dimensions for workspace {self.id} -')

            self.get_dimensions_response = requests.get(
                self.connection.api_url + f'/v1/workspaces/{self.id}/dimensions',
                headers = self.connection.standard_header  
            )
            self.connection.add_call()

            if self.get_dimensions_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_dimensions_response.status_code}')
                raise Bad_HTTP_Response(self.get_dimensions_response.status_code)

            self.dimensions = self.get_dimensions_response.json()

            if self.connection.verbose:
                print( f'\tresponse: {self.get_dimensions_response.status_code}' )
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'get_dimensions','timestamp':dt.now(),'error':str(X),'response':str(self.get_dimensions_response),'workspace':self.id}
            )


    def get_streams(self):
        '''
        Get request to pull the list of workstreams by workspace id.
        Initializes the 'streams' attribute and populates the list from the api json response.
            Inputs:
                workspace_id (string or integer)
        '''

        try:
            if self.connection.verbose:
                print(f'- getting data streams for {self.id} -')

            self.get_streams_response = requests.get(
                self.connection.api_url + f'/v1/workspaces/{self.id}/data-streams',
                headers = self.connection.standard_header  
            )
            self.connection.add_call()

            if self.get_streams_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_streams_response.status_code}')
                raise Bad_HTTP_Response(self.get_streams_response.status_code)

            streams_content = self.get_streams_response.json()
            for dstr in streams_content:
                self.streams.update( {dstr.get('id'):Stream(self,attributes=dstr) } )

            if self.connection.verbose:
                print( f'\tresponse: {self.get_streams_response.status_code}' )
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'get_streams','timestamp':dt.now(),'error':str(X),'response':str(self.get_streams_response),'workspace':self.id}
            )


    def get_calculated_measurements(self):
        ''''''

        try:
            if self.connection.verbose:
                print(f'- getting calculated measures for {self.id} -')

            self.get_calc_measures_response = requests.get(
                self.connection.api_url + f'/v1/workspaces/{self.id}/calculated-measurements',
                headers = self.connection.standard_header  
            )
            self.connection.add_call()

            if self.get_calc_measures_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_calc_measures_response.status_code}')
                raise Bad_HTTP_Response(self.get_calc_measures_response.status_code)

            self.calculated_measures = self.get_calc_measures_response.json()

            if self.connection.verbose:
                print( f'\tresponse: {self.get_calc_measures_response.status_code}' )
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'get_calculated_measurements','timestamp':dt.now(),'error':str(X),'response':str(self.get_calc_measures_response),'workspace':self.id}
            )


    def create_calculated_measurement(self,params):
        ''''''

        try:
            if self.connection.verbose:
                print(f'- getting calculated measures for {self.id} -')

            self.create_calc_measures_response = requests.request(
                'POST',
                self.connection.api_url + f'/v1/workspaces/{self.id}/calculated-measurements',
                headers = self.connection.standard_header,
                data=params
            )
            self.connection.add_call()

            if self.create_calc_measures_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.create_calc_measures_response.status_code}')
                raise Bad_HTTP_Response(self.create_calc_measures_response.status_code)

            if self.connection.verbose:
                print( f'\tresponse: {self.create_calc_measures_response.status_code}' )
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'create_calculated_measurement','timestamp':dt.now(),'error':str(X),'response':self.create_calc_measures_response.content,'workspace':self.id}
            )


    def create_stream(self,params):
        '''
        - Untested -
        Creates a datastream in the current workspace based on the given stream parameters.
            Inputs:
                params (dictionary)
                    The parameters used to define the datastream. Example below:
                    {
                    "id": 1234,
                    "name": "Data stream",
                    "dataSourceId": 1,
                    "dataSourceName": "Google Analytics",
                    "workspaceId": 10,
                    "parentInstanceId": null,
                    "channelId": 1,
                    "dataSourceAuthenticationId": 2,
                    "email": null,
                    "description": null,
                    "config": {
                        "externalIdentifier": "999999",
                        "name": "acme.com - acme.com (999999)",
                        "getExtendedProperties": true,
                        "locationBreakdown": "COUNTRY",
                        "selectedObjects": [],
                        "allowDelete": null,
                        "oldestDate": null,
                        "parentExternalIdentifier": null,
                        "parentName": null,
                        "currency": "USD",
                        "accountId": "9999999",
                        "profileId": "999999",
                        "webPropertyId": "UA-9999999-9",
                        "profileName": "acme.com",
                        "websiteUrl": "acme.com",
                        "getCampaigns": true,
                        "getKeywords": false,
                        "getGoals": false,
                        "getEvents": false,
                        "getPages": true,
                        "getEventLabelDimension": false,
                        "mapAsDeliveryEntities": true,
                        "pageLevels": "2"
                    },
                    "dataLoadMode": "REPLACE",
                    "dataLoadRulesConfig": "[]",
                    "dataLoadRules": [],
                    "sourceDisplayName": "Google Analytics",
                    "enabled": true,
                    "lastUpdate": null,
                    "lastRunStatus": false,
                    "daysWithoutData": 0,
                    "originalDataStreamId": null,
                    "originalId": null,
                    "dimensionOnly": false,
                    "enableSlowlyChangingDimension": false,
                    "hasData": true,
                    "retrievalEnabled": false,
                    "retrievalPeriodType": "DAILY",
                    "retrievalPeriodData": null,
                    "retrievalPeriodHour": null,
                    "lagInDays": null,
                    "retrievalNextDate": 1522638000000,
                    "retrievalDeliveryMethod": null,
                    "retrievalDeliveryMethodDetails": null,
                    "ignoreEmptyRows": true,
                    "fileWildcard": null,
                    "initRuleAfterUpdate": true,
                    "slidingWindow": null,
                    "defaultSlidingWindow": 1,
                    "defaultFetchDaySpan": 10,
                    "fetchDaySpan": null,
                    "templateId": null,
                    "lastDataDate": null,
                    "enableHourlyBreakdown": false,
                    "pendingStatsCount": 0,
                    "processStatsCounts": 0,
                    "customAttribute1": "",
                    "customAttribute2": "",
                    "customAttribute3": "",
                    "overrideHierarchies": false,
                    "useCultureSettings": false,
                    "allowHourlyProcessing": false,
                    "lastRowsRetrieved": null,
                    "dataPreviewPageId": null,
                    "deletePreviousDimensionData": false,
                    "runOnlyAsPartOfWorkflow": false,
                    "enableParallelRun": true,
                    "oneClickTemplateId": null
                    }
        '''

        try:
            if not params.get('name'):
                if self.connection.verbose:
                    print('Input parameters missing stream name.')
                raise MissingStreamName()
            
            if self.connection.verbose:
                print(f'- creating data stream {params.get("name")} -')

            self.create_response = requests.request(
                'POST',
                self.connection.api_url + '/v1/data-streams',
                data=params
            )
            self.connection.add_call()

            if self.create_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.create_response.status_code}')
                raise Bad_HTTP_Response(self.create_response.status_code)

            stream_content = self.create_response.json()
            self.streams.update( {stream_content.get('id'):stream_content} )

            if self.connection.verbose:
                print(f'\tresponse: {self.create_response.status_code}')
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'workspace','function':'create_stream','timestamp':dt.now(),'error':str(X),'response':str(self.create_response),'workspace':self.id}
            )