import requests,json
from datetime import datetime as dt

from Datorama import Bad_HTTP_Response


class Job():
    def __init__(self,stream,attributes=None,job_id=None):
        self.connection = stream.connection
        self.logs = stream.logs
        if job_id:
            self.id = job_id
            self.get_meta_data()
        if attributes:
            self.__dict__.update(attributes)


    def get_meta_data(self):
        ''' Retreives the meta data for the job. '''

        try:
            if self.connection.verbose:
                print('- getting workspace metadata -')

            self.get_meta_data_response = requests.get(
                self.connection.api_url + f'/v1/data-stream-stat/{self.id}',
                headers = self.connection.standard_header
            )
            self.connection.add_call()

            if self.get_meta_data_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_meta_data_response.status_code}')
                raise Bad_HTTP_Response(self.get_meta_data_response.status_code)

            output = self.get_meta_data_response.json()
            
            self.__dict__.update(output)

            if self.connection.verbose:
                print( f'\tresponse: {self.get_meta_data_response}' )
                print('- done -')

        
        except Exception as X:
            self.logs['error_log'].append(
                {'module':'job','function':'get_meta_data','timestamp':dt.now(),'error_raised':str(X),'api_response':str(self.get_meta_data_response.content) }
            )


    def rerun(self):
        ''' Rerun the job. '''

        try:
            if self.connection.verbose:
                print(f'- rerunning stream: {self.dataStreamId} job_ids: {self.id} -')
            
            payload = json.dumps([self.id])
            self.rerun_response = requests.request(
                "POST",
                self.connection.api_url + f'/v1/data-streams/api/{self.dataStreamId}/rerun',
                headers = self.connection.standard_header,
                data = payload
            )
            self.connection.add_call()

            if self.rerun_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.rerun_response.status_code}')
                raise Bad_HTTP_Response(self.rerun_response.status_code)

            self.rerun_content = self.rerun_response.json()
            self.logs['rerun_log'].append( {'timestamp':dt.now(),'stream':self.dataStreamId,'result':'success','job_id':self.id} )
            
            if self.connection.verbose:
                print( f'\tresponse: {self.rerun_response}' )
                print('- done -')
        
        except Exception as X:
            self.logs['error_log'].append(
                {'module':'job','function':'rerun','timestamp':dt.now(),'error':str(X),'response':self.rerun_response.content,'stream':self.dataStreamId}
            )
            self.logs['rerun_log'].append( {'timestamp':dt.now(),'stream':self.dataStreamId,'result':'error','job_id':self.id} )
