from time import sleep
from datetime import datetime as dt

class Connect():
    ''' Connection class that retains the connection parameters. '''

    def __init__(self,api_token,verbose,pause):
        self.verbose,self.pause = verbose,pause
        self.api_url = 'https://api-us2.datorama.com'
        self.standard_header = {'Authorization':api_token,'Accept':'application/json','Content-Type':'application/json'}
        self.active_platform_calls = 0
        self.total_calls = 0
        self.platform_calls = []


    def add_call(self):
        ''''''

        self.total_calls += 1
        self.platform_calls.append( dt.now() )
        self.update_calls()


    def update_calls(self):
        ''''''

        self.platform_calls = [x for x in self.platform_calls if (dt.now() - x).seconds < 61]
        self.active_platform_calls = len(self.platform_calls)
        self.check_calls()


    def check_calls(self):
        ''''''

        while self.active_platform_calls > 59:
            print('rate limit reached, pausing...')
            sleep(10)
            self.update_calls

        if self.verbose:
            print(self.active_platform_calls)

        else: pass