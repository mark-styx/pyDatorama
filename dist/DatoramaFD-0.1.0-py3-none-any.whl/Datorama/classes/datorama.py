import requests,time,os,pickle
import numpy as np
import pandas as pd
from math import ceil
from time import sleep
from datetime import datetime as dt

from Datorama import Connect,Workspace,Bad_HTTP_Response,Unequal_Input_Error


class datorama():
    '''
    Main class representing the parent Datorama object.
        Inputs:
            api_token (str)
                The api token provided by Datorama.
            verbose (boolean)
                Determines the amount of feedback to be returned to the user. Useful for debugging.
            pause (int,float)
                The length of time to sleep between standard iterated requests.
                The Datorama platform api has a limit of 60 requests per minute so the default pause is 1 second.
    '''

    def __init__(self,api_token,verbose=False,pause=1.5):
        self.connection = Connect(api_token,verbose,pause)
        self.logs = {
            'rerun_log':{},'process_log':{},
            'update_log':[],'error_log':{}
        }
        self.jobs = {}
        self.streams = {}
        self.get_workspaces()


    def get_workspaces(self):
        '''Get request to pull the metadata for all workspaces from the api.'''
        
        try:
            if self.connection.verbose:
                print('getting workspaces')

            self.get_workspaces_response = requests.get(
                self.connection.api_url + '/v1/workspaces',
                headers = self.connection.standard_header
            )
            self.connection.add_call()

            if self.get_workspaces_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_workspaces_response.status_code}')
                raise Bad_HTTP_Response(self.get_workspaces_response.status_code)

            self.ws_content = self.get_workspaces_response.json()
            self.workspaces = [ {ws.get('id'):Workspace(self,attributes=ws) } for ws in self.ws_content]
            time.sleep(self.connection.pause)

            if self.connection.verbose:
                print( f'\tresponse: {self.get_workspaces_response}' )
                print('- done -')
        
        except Exception as X:
            self.logs['error_log'].update(
                {'module':'datorama','function':'get_workspaces','timestamp':str(dt.now() ),'error_raised':str(X),'api_response':str(self.get_workspaces_response.content) }
            )


    def _feedback(self,timeseries,length,index,split=4):
        '''
        Returns feedback to the user about the iteration progress.
            Inputs:
                timeseries (pandas.series)
                    A pandas series containing the execution time of each iteration.
                length (int)
                    The total length of the iteration.
                index (int)
                    The current iteration index.
                split (int)
                    The number of slices to split the dataset into; Used to determine when to provide feedback.
        '''

        if index in [ ( (length//split) * i) for i in range(1,split) ] and length > 2:
                print(f'\tprogress: { round( (index/length*100), 2) }%')
                print(f'\test compl: { timeseries.mean() * (length - index + 1) }')


    def get_all_dimensions(self):
        '''Loop through all workspaces and retrieve the dimensions.'''

        print('- getting dimensions for all workspaces -')

        print('\tmaking calls to api')
        self.dimensions = {}
        cnt = len(self.workspaces)
        ts = pd.Series()
        for idx,item in enumerate(self.workspaces):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            for space in item.values():
                space.get_dimensions()
                self.dimensions.update( {space.id:space.dimensions} )

            time.sleep(self.connection.pause)
            ts = ts.append(pd.Series(dt.now()-st) )        
        print('\tdone')


    def get_all_streams_meta(self,export=False,export_name='Datorama Stream Meta Data',workspaces=None):
        '''
        Loops through all workspace objects and triggers each ones 'get_streams' function.
            Inputs:
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
                export_name (str)
                    The output filename with extension. Must be a csv file.
        '''

        if not workspaces:
            workspaces = self.workspaces
        else:
            workspaces = {k:v for x in self.workspaces for k,v in x.items() if v.id in workspaces}
            workspaces = [ {k:v} for k,v in workspaces.items() ]

        fields = [
                    'id','name','dataSourceId','sourceDisplayName','workspaceId',
                    'enabled','hasData','dataSourceAuthenticationId','createTime',
                    'lastUpdate','lastRunStatus','lastRowsRetrieved','processedRows',
                    'lastDataDate'
                ]

        print('- getting metadata for all streams -')

        print('\tmaking calls to api')
        cnt = len(workspaces)
        ts = pd.Series()
        for idx,item in enumerate(workspaces):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            for space in item.values():
                space.get_streams()

            time.sleep(self.connection.pause)
            ts = ts.append(pd.Series(dt.now()-st) )        
        print('\tdone')

        print('\torganizing return data')
        cnt = len(self.streams)
        ts = pd.Series()
        self.stream_meta = []
        for idx,stream in enumerate(self.streams.values() ):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            self.stream_meta.append( {x:stream.__dict__.get(x) for x in stream.__dict__ if x in fields} )
            
            ts = ts.append(pd.Series(dt.now()-st) )
        print('\tdone')

        self.stream_df = pd.DataFrame(self.stream_meta).reset_index()
        self.stream_df['createTime'] = pd.to_datetime(self.stream_df['createTime'],unit='ms')
        self.stream_df['lastUpdate'] = pd.to_datetime(self.stream_df['lastUpdate'],unit='ms')

        if export:
            self.stream_df.to_csv(export_name,index=False)
        print('- done -')


    def get_all_jobs_meta(self,export=False,export_name='Datorama Job Run Data'):
        '''
        Loops through all data stream objects and triggers each ones 'get_stream_runs' function.
            Inputs:
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
                export_name (str)
                    The output filename with extension. Must be a csv file.
        '''

        exclusions = ['connection','logs']
        print('- getting metadata for all stream runs -')
        if not self.streams:
            self.get_all_streams_meta()

        print('\tmaking calls to api')
        cnt = len(self.streams)
        ts = pd.Series()
        for idx,stream in enumerate(self.streams):
            st = dt.now()
            self._feedback(ts,cnt,idx,split=8)
            
            self.streams.get(stream).get_stream_runs()

            time.sleep(self.connection.pause)
            ts = ts.append(pd.Series(dt.now()-st) )
        print('\tdone')

        print('\torganizing return data')
        cnt = len(self.streams)
        ts = pd.Series()
        self.job_meta = []
        for idx,job in enumerate(self.jobs.values() ):
            st = dt.now()
            self._feedback(ts,cnt,idx,split=8)

            self.job_meta.append( {x:job.__dict__.get(x) for x in job.__dict__ if x not in exclusions} )
            
            ts = ts.append(pd.Series(dt.now()-st) )
        print('\tdone')

        self.jobs_df = pd.DataFrame(self.job_meta).reset_index()
        self.jobs_df['startExecutionTime'] = pd.to_datetime(self.jobs_df['startExecutionTime'],unit='ms')
        self.jobs_df['endExecutionTime'] = pd.to_datetime(self.jobs_df['endExecutionTime'],unit='ms')

        if export:
            self.jobs_df.drop('processLog',axis=1).to_csv(export_name,index=False)
        print('- done -')


    def bulk_process_streams(self,streams,starts,ends,log_file='process_log.csv',error_file='error_log.csv',d_range=10,export=True):
        '''
        Process an iterable of stream ids using the process_stream() function. Streams, starts, and ends must be the same length.
            Inputs:
                streams (iterable)
                    The list, array, or series representing the list of stream ids to process.
                starts (iterable)
                    The list, array, or series representing the list of start dates to process.
                ends (iterable)
                    The list, array, or series representing the list of end dates to process.
                d_range (integer)
                    Days to partition the day range by.
                log_file (str)
                    The output filename with extension for the process log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                error_file (str)
                    The output filename with extension for the error log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        if not self.streams:
            self.get_all_streams_meta()

        if not ( len(streams) == len(starts) == len(ends) ):
            raise Unequal_Input_Error()

        ts = pd.Series()
        cnt = len(streams)
        print(f'- processing {cnt} jobs -')
        for idx,(stream,start,end) in enumerate( zip(streams,starts,ends) ):
            st = dt.now()
            self._feedback(ts,cnt,idx)
    
            days = pd.DatetimeIndex(start=start, end=end, freq='D').tolist()
            if len(days) > d_range:
                days = np.array_split(days,ceil(len(days)/d_range) )
                st_part = [str(d[0].date() ) for d in days]
                en_part = [str(d[-1].date() ) for d in days]
                for st_pt,en_pt in zip(st_part,en_part):
                    self.streams.get(stream).process(st_pt,en_pt)

            else:
                self.streams.get(stream).process(start,end)

            time.sleep(self.connection.pause)
            ts = ts.append(pd.Series(dt.now()-st) )

        if export:
            process_log = pd.DataFrame(self.logs['process_log']).reset_index()
            if log_file and os.path.exists(log_file):
                old_process_log = pd.read_csv(log_file)
                process_log = pd.DataFrame(self.logs['process_log']).append(old_process_log)
            process_log = process_log.drop_duplicates()
            process_log.to_csv(log_file,index=False)

            error_log = pd.DataFrame(self.logs['error_log'])
            if error_file and os.path.exists(error_file):
                old_error_log = pd.read_csv(error_file)
                error_log = pd.DataFrame(self.logs['error_log']).append(old_error_log)
            error_log = error_log.drop_duplicates()
            error_log.to_csv(error_file,index=False)
        print('- done -')


    def bulk_rename_streams(self,streams,names,export=True,update_file='update_log.csv',error_file='error_log.csv'):
        '''
        Packages the name into a dictionary and passes it to the streams' 'update_stream' function.
            Inputs:
                streams (integer, string, or list)
                names (string or list)
                update_file (str)
                    The output filename with extension for the update log. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        if not self.streams:
            self.get_all_streams_meta()

        if type(streams) not in (str,int) and type(names) not in (str,int):    
            if not (len(streams) == len(names) ):
                raise Unequal_Input_Error()
        else:
            streams,names = [streams],[names]
        
        ts = pd.Series()
        cnt = len(streams)
        print(f'- updating {cnt} streams -')
        for idx,(stream,name) in enumerate( zip(streams,names) ):
            st = dt.now()
            self._feedback(ts,cnt,idx)
            
            self.streams.get(stream).update_stream( {'name':name} )

            time.sleep(self.connection.pause)
            ts = ts.append(pd.Series(dt.now()-st) )

        if export:
            update_log = pd.DataFrame(self.logs['update_log'])
            if update_file and os.path.exists(update_file):
                old_update_log = pd.read_csv(update_file)
                update_log = update_log.append(old_update_log)
            update_log.to_csv(update_file,index=False)

            error_log = pd.DataFrame(self.logs['error_log'])
            if error_file and os.path.exists(error_file):
                old_error_log = pd.read_csv(error_file)
                error_log = pd.DataFrame(self.logs['error_log']).append(old_error_log)
            error_log = error_log.drop_duplicates()
            error_log.to_csv(error_file,index=False)
        print('- done -')


    def bulk_rerun_jobs(self,streams,jobs,export=True,rerun_file='rerun_log.csv',error_file='error_log.csv',queue_limit=10):
        '''
        Groups the jobs by their stream and passes the list of jobs to the streams' 'rerun_job_batch' function.
            Inputs:
                streams (list)
                    List representing the stream that each job belongs to.
                jobs (list)
                    List representing the job ids to rerun.
                log_file (str)
                    The output filename with extension. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                error_file (str)
                    The output filename with extension. Must be a csv file.
                    For the previous log to be appended, the filename must be the same.
                export (boolean)
                    Whether to export the resulting data frame to a csv file.
        '''

        if not self.streams:
            self.get_all_streams_meta()
        
        rerun_df = pd.DataFrame( {'stream':streams,'job':jobs} )

        workspaces = {k:v for x in self.workspaces for k,v in x.items() }
        reruns = {x:{'jobs':[],'status':'na','space':workspaces.get(self.streams.get(x).workspaceId) } for x in streams}
        for x in reruns:
            reruns[x]['jobs'] = rerun_df[rerun_df['stream'] == x]['job'].to_list()
        print([x.name for x in workspaces.values()])
        print([v.get('space').name for v in reruns.values()])
        ts = pd.Series()
        cnt = len(reruns)
        print(f'- rerunning {cnt} streams -')
        complete = False
        while not complete:
            for idx,stream in enumerate(reruns):
                
                if reruns[stream]['status'] not in ['na','pending','queued']:
                    continue

                print(stream,idx)
                print(reruns[stream]['status'])

                st = dt.now()
                self._feedback(ts,cnt,idx,split=16)
                
                reruns[stream]['space'].queue_check('rerun_log')
                if reruns.get(stream)['space'].pending > queue_limit:
                    print('\tqueue full, going to next stream')
                    continue
                
                if reruns[stream]['status'] == 'na':
                    self.streams.get(stream).rerun_job_batch( reruns[stream]['jobs'] )
                    reruns[stream]['status'] = 'queued'
                    ts = ts.append(pd.Series(dt.now()-st) )

                with open('./rerun_status.pkl','wb') as f:
                    pickle.dump(reruns,f)
                sleep(self.connection.pause)
            
            for stream in reruns:
                stat = [self.logs['rerun_log'].get(x)['result'] == 'success' for x in reruns[stream]['jobs'] if self.logs['rerun_log'].get(x)]
                if any(stat): reruns[stream]['status'] = 'pending'
                if all(stat): reruns[stream]['status'] = 'success'

            if all( [job.get('space').pending > queue_limit for job in reruns.values()] ):
                print('all queues full, sleeping for 30 seconds')
                sleep(30)
            
            if all( [job.get('status') != 'na' for job in reruns.values()] ):
                print('all jobs completed or pending, recheck in 1 minute')
                sleep(60)
                        
            if not [x for x in reruns.values() if x.get('status') != 'success']:
                complete = True
                

        if export:
            rerun_log = pd.DataFrame( [x for y in dr.logs['rerun_log'].values() for x in y.values()] )
            if rerun_file and os.path.exists(rerun_file):
                old_rerun_log = pd.read_csv(rerun_file)
                rerun_log = rerun_log.append(old_rerun_log)
            rerun_log.to_csv(rerun_file,index=False)

            error_log = pd.DataFrame(self.logs['error_log'])
            if error_file and os.path.exists(error_file):
                old_error_log = pd.read_csv(error_file)
                error_log = pd.DataFrame(self.logs['error_log']).append(old_error_log)
            error_log = error_log.drop_duplicates()
            error_log.to_csv(error_file,index=False)
        print('- done -')