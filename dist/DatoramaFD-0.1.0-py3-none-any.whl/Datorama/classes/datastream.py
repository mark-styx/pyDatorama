import requests,json
from datetime import datetime as dt

from Datorama import Bad_HTTP_Response,DateInputError
from Datorama import Job

class Stream():

    def __init__(self,workspace,attributes=None,stream_id=None):
        self.connection = workspace.connection
        self.jobs = workspace.jobs
        self.logs = workspace.logs
        if stream_id:
            self.id = stream_id
            self.get_meta_data()
        if attributes:
            self.__dict__.update(attributes)

    
    def get_meta_data(self,ret=False):
        ''' Gathers the meta data for the stream. If ret=True, the response is returned. '''
        
        try:
            if self.connection.verbose:
                print('- getting workspace metadata -')

            self.get_meta_data_response = requests.get(
                self.connection.api_url + f'/v1/data-streams/{self.id}',
                headers = self.connection.standard_header
            )
            self.connection.add_call()

            if self.get_meta_data_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_meta_data_response.status_code}')
                raise Bad_HTTP_Response(self.get_meta_data_response.status_code)

            output = self.get_meta_data_response.json()
            
            if ret:
                return output

            self.__dict__.update(output)

            if self.connection.verbose:
                print( f'\tresponse: {self.get_meta_data_response}' )
                print('- done -')

        
        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'get_meta_data','timestamp':dt.now(),'error_raised':str(X),'api_response':str(self.get_meta_data_response.content) }
            )
    

    def process(self,start,end):
        '''
        Process the input stream between the start and end date.
            Inputs:
                start (string)
                    formatted yyyy-mm-dd
                end (string)
                    formatted yyyy-mm-dd
        '''

        try:
            if self.connection.verbose:
                print(f'- processing {self.id} from {start} through {end} -')
            
            if type(start) is str and ':' in start: raise DateInputError(start)
            if type(end) is str and ':' in end: raise DateInputError(end)

            payload = json.dumps({'startDate':start,'endDate':end})
            self.process_response = requests.request(
                "POST",
                self.connection.api_url + f'/v1/data-streams/{self.id}/process',
                headers = self.connection.standard_header,
                data = payload
            )
            self.connection.add_call()

            if self.process_response.status_code != 200: # disabled streams and bad date ranges will return 422
                if self.connection.verbose:
                    print(f'\terror: {self.process_response.status_code}')
                raise Bad_HTTP_Response(self.process_response.status_code)
            
            if self.connection.verbose:
                print( f'\tresponse: {self.process_response}' )

            self.process_content = self.process_response.json() # may return error; not sure how the total connect will respond
            
            job_ids = [x.get('id') for x in self.process_content]
            for job_id in job_ids:
                self.logs['process_log'].update(
                    {self.id:{job_id:{'timestamp':dt.now(),'stream':self.id,'start':start,'end':end,'result':'pending','job_id':job_id,'completed':'NULL'} } }
                )

            if self.connection.verbose:
                print('- done -')
        

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'process','timestamp':dt.now(),'error':str(X),'response':self.process_response.content,'stream':self.id}
            )
            self.logs['process_log'].update(
                {self.id:{job_id:{'timestamp':dt.now(),'stream':self.id,'start':start,'end':end,'result':'pending','job_id':job_id,'completed':'NULL'} } }
            )


    def get_mapping(self):
        '''Gets the current mapping of the datastream.'''

        try:
            if self.connection.verbose:
                print(f'- getting stream mapping for {self.id} -')
            
            self.get_mapping_response = requests.get(
                self.connection.api_url + f'data-streams/api/{self.id}/mapping',
                self.connection.standard_header
            )
            self.connection.add_call()

            if self.get_mapping_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.get_mapping_response.status_code}')
                raise Bad_HTTP_Response(self.get_mapping_response.status_code)

            self.mapping = self.get_mapping_response.json()

            if self.connection.verbose:
                print( f'\tresponse: {self.get_mapping_response}' )
                print('- done -')


        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'get_mapping','timestamp':dt.now(),'error':str(X),'response':self.get_mapping_response.content,'stream':self.id}
            )

    
    def update_mapping(self,params):
        '''
        Update the mapping configuration for a data stream.
            Inputs:
                params (dictionary)
        '''

        try:
            if self.connection.verbose:
                print(f'- updating stream mapping for {self.id} -')

            self.get_mapping()
            old_params = self.mapping

            self.mapping.update(params)
            self.update_mapping_response = requests.request(
                'PUT',
                self.connection.api_url + f'data-streams/api/{self.id}/mapping',
                self.connection.standard_header,
                data=self.mapping
            )
            self.connection.add_call()

            if self.update_mapping_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.update_mapping_response.status_code}')
                raise Bad_HTTP_Response(self.update_mapping_response.status_code)

            self.logs['update_log'].append(
                {'stream':self.id,'new_params':params,'old_params':old_params,'status':'success','timestamp':dt.now() }
            )

            if self.connection.verbose:
                print( f'\tresponse: {self.update_mapping_response}' )
                print('- done -')


        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'get_mapping','timestamp':dt.now(),'error':str(X),'response':self.update_mapping_response.content,'stream':self.id}
            )
            self.logs['update_log'].append( {'stream':self.id,'params':str(params),'status':'failed','timestamp':dt.now() } )


    def update_stream(self,params):
        '''
        Updates a data stream based on the passsed parameters.
            Inputs:
                stream (integer or string)
                params (dictionary)
        '''

        try:
            if self.connection.verbose:
                print(f'- updating stream: {self.id} -')

            stream_meta = self.get_meta_data(True)
            stream_meta.update(params)

            self.update_response = requests.request(
                "PUT",
                self.connection.api_url + f'/v1/data-streams/{self.id}',
                headers = self.connection.standard_header,
                data=json.dumps(stream_meta)
            )
            self.connection.add_call()

            if self.update_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.update_response.status_code}')
                raise Bad_HTTP_Response(self.update_response.status_code)

            old_params = {attr:self.__dict__.get(attr) for attr in self.__dict__ if attr in params}
            self.logs['update_log'].append(
                {'stream':self.id,'new_params':params,'old_params':old_params,'status':'success','timestamp':dt.now() }
            )

            if self.connection.verbose:
                print( f'\tresponse: {self.update_response}' )
                print('- done -')
        

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'update','timestamp':dt.now(),'error':str(X),'response':self.update_response.content,'stream':self.id}
            )
            self.logs['update_log'].append( {'stream':self.id,'params':str(params),'status':'failed','timestamp':dt.now() } )

    
    def rerun_all_jobs(self):
        ''' Rerun all jobs for the data stream. '''

        try:
            if self.connection.verbose:
                print(f'- rerunning stream: {self.id} -')

            self.rerun_all_response = requests.request(
                "POST",
                self.connection.api_url + f'/v1/data-streams/api/{self.id}/rerun-all',
                headers = self.connection.standard_header
            )
            self.connection.add_call()

            if self.rerun_all_response.status_code != 200:
                if self.connection.verbose:
                    print(f'\terror: {self.rerun_all_response.status_code}')
                raise Bad_HTTP_Response(self.rerun_all_response.status_code)

            self.rerun_all_content = self.rerun_all_response.json()
            job_ids = [x.get('id') for x in self.rerun_all_content]
            for job_id in job_ids:
                self.logs['rerun_log'].update(
                    {self.id:{job_id:{'timestamp':dt.now(),'stream':self.id,'result':'pending','job_id':job_id,'completed':'NULL'} } }
                )

            if self.connection.verbose:
                print( f'\tresponse: {self.rerun_all_response}' )
                print('- done -')
        
        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'rerun_all_jobs','timestamp':dt.now(),'error':str(X),'response':self.rerun_all_response.content,'stream':self.id}
            )


    def get_stream_runs(self,pgSize=100,pgNum=1):
        '''
        Post request to return the list of stream stats by workstream id. Set to page size of 150.
            Inputs:
                pgSize (integer)
                    Not really relevant now as the page numbers should loop until there are no more rows.
                pgNum (integer)
                    Not really relevant now as the page numbers should loop until there are no more rows.
        '''
        
        try:
            if self.connection.verbose:
                print( f'- getting stream runs for: {self.id} -' )
            
            endOfList = False
            while not endOfList:
                
                try:
                    payload = json.dumps( {'pageSize':pgSize,'pageNumber':pgNum} )
                    self.runs_response = requests.request(
                        "POST",
                        self.connection.api_url + f'/v1/data-streams/api/{self.id}/stats',
                        headers = self.connection.standard_header,
                        data = payload
                    )
                    self.connection.add_call()

                    if self.runs_response.status_code != 200:
                        if self.connection.verbose:
                            print(f'\terror: {self.runs_response.status_code}')
                        raise Bad_HTTP_Response(self.runs_response.status_code)
                    
                    self.runs_content = self.runs_response.json()
                    if len(self.runs_content) == 0:
                        endOfList=True
                    
                    for stat in self.runs_content:
                        self.jobs.update( {stat.get('id'):Job(self,attributes=stat) } )
                    
                    pgNum += 1 # Next page
                
                except:
                    endOfList = True
            
            if self.connection.verbose:
                print( f'\tresponse: {self.runs_response}' )
                print('- done -')

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'get_stream_runs','timestamp':dt.now(),'error':str(X),'response':str(self.runs_response.content),'stream':self.id}
            )
            

    def rerun_job_batch(self,job_ids):
        '''
        Rerun a list of job ids for a single datastream id.
            Inputs:
                job_ids (list, integer, or string)
        '''

        try:
            if self.connection.verbose:
                print(f'- rerunning stream: {self.id} job_ids: {job_ids} -')
            
            if type(job_ids) is not list: job_ids = [job_ids]
            payload = json.dumps(job_ids)
            self.rerun_response = requests.request(
                "POST",
                self.connection.api_url + f'/v1/data-streams/api/{self.id}/rerun',
                headers = self.connection.standard_header,
                data = payload
            )
            self.connection.add_call()

            if self.rerun_response.status_code != 200:
                if self.connection.verbose:
                    print(f'error: {self.rerun_response.status_code}')
                raise Bad_HTTP_Response(self.rerun_response.status_code)
            
            if self.connection.verbose:
                print( f'response: {self.rerun_response}' )

            self.rerun_content = self.rerun_response.json() # may return error; not sure how the total connect will respond
            job_ids = [x.get('id') for x in self.rerun_content]
            for job_id in job_ids:
                self.logs['rerun_log'].update(
                    { self.id:{job_id:{'timestamp':dt.now(),'stream':self.id,'result':'pending','job_id':job_id,'completed':'NULL'} } }
                )

        except Exception as X:
            self.logs['error_log'].append(
                {'module':'datastream','function':'rerun_job_batch','timestamp':dt.now(),'error':str(X),'response':self.rerun_response.content,'stream':self.id}
            )
            for job_id in job_ids:
                self.logs['rerun_log'].update(
                    {self.id:{job_id:{'timestamp':dt.now(),'stream':self.id,'result':'error','job_id':job_id,'completed':'NULL'} } }
            )